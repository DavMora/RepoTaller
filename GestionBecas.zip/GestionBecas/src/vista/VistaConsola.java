/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;


import controlador.ControladorBeca;
import modelo.Beca;
import java.util.ArrayList;
import java.util.Scanner;

public class VistaConsola {

    private ControladorBeca controlador;
    private Scanner scanner;

    public VistaConsola() {
        controlador = new ControladorBeca();
        scanner = new Scanner(System.in);
    }

    public void menu() {
        int opcion = -1;

        do {
            System.out.println("\n--- Sistema Gestión Becas ---");
            System.out.println("1. Registrar beca");
            System.out.println("2. Listar becas");
            System.out.println("3. Buscar beca por cédula");
            System.out.println("4. Modificar beca");
            System.out.println("5. Eliminar beca");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");

            try {
                opcion = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Opción inválida. Intente de nuevo.");
                continue;
            }

            switch (opcion) {
                case 1 -> registrarBeca();
                case 2 -> listarBecas();
                case 3 -> buscarBeca();
                case 4 -> modificarBeca();
                case 5 -> eliminarBeca();
                case 0 -> System.out.println("Saliendo...");
                default -> System.out.println("Opción inválida.");
            }
        } while (opcion != 0);
    }

    private void registrarBeca() {
        System.out.println("\n--- Registrar Beca ---");
        System.out.print("Cédula: ");
        String cedula = scanner.nextLine().trim();
        System.out.print("Nombres: ");
        String nombres = scanner.nextLine().trim();
        System.out.print("Carrera: ");
        String carrera = scanner.nextLine().trim();
        System.out.print("Tipo de beca (económica/académica): ");
        String tipo = scanner.nextLine().trim().toLowerCase();
        System.out.print("Semestre: ");
        int semestre;
        try {
            semestre = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Semestre inválido.");
            return;
        }

        Double ingreso = null;
        Double promedio = null;

        if (tipo.equals("económica")) {
            System.out.print("Ingreso familiar: ");
            try {
                ingreso = Double.parseDouble(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Ingreso familiar inválido.");
                return;
            }
        } else if (tipo.equals("académica")) {
            System.out.print("Promedio académico: ");
            try {
                promedio = Double.parseDouble(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Promedio académico inválido.");
                return;
            }
        } else {
            System.out.println("Tipo de beca inválido.");
            return;
        }

        boolean exito = controlador.registrarBeca(cedula, nombres, carrera, tipo, semestre, ingreso, promedio);

        if (exito) {
            System.out.println("Beca registrada correctamente.");
        } else {
            System.out.println("Error al registrar la beca.");
        }
    }

    private void listarBecas() {
        System.out.println("\n--- Lista de Becas ---");
        ArrayList<Beca> lista = controlador.listarBecas();
        if (lista.isEmpty()) {
            System.out.println("No hay becas registradas.");
            return;
        }
        for (Beca b : lista) {
            mostrarBeca(b);
        }
    }

    private void buscarBeca() {
        System.out.print("\nIngrese la cédula para buscar: ");
        String cedula = scanner.nextLine().trim();
        Beca b = controlador.buscarBeca(cedula);
        if (b == null) {
            System.out.println("No se encontró la beca con esa cédula.");
        } else {
            mostrarBeca(b);
        }
    }

    private void modificarBeca() {
        System.out.println("\n--- Modificar Beca ---");
        System.out.print("Cédula del beneficiario a modificar: ");
        String cedula = scanner.nextLine().trim();

        Beca b = controlador.buscarBeca(cedula);
        if (b == null) {
            System.out.println("No existe beca con esa cédula.");
            return;
        }

        System.out.print("Nuevos nombres (" + b.getNombres() + "): ");
        String nombres = scanner.nextLine().trim();
        if (nombres.isEmpty()) nombres = b.getNombres();

        System.out.print("Nueva carrera (" + b.getCarrera() + "): ");
        String carrera = scanner.nextLine().trim();
        if (carrera.isEmpty()) carrera = b.getCarrera();

        System.out.print("Nuevo tipo de beca (" + b.getTipoBeca() + "): ");
        String tipo = scanner.nextLine().trim().toLowerCase();
        if (tipo.isEmpty()) tipo = b.getTipoBeca();

        System.out.print("Nuevo semestre (" + b.getSemestre() + "): ");
        String semestreStr = scanner.nextLine().trim();
        int semestre = b.getSemestre();
        if (!semestreStr.isEmpty()) {
            try {
                semestre = Integer.parseInt(semestreStr);
            } catch (NumberFormatException e) {
                System.out.println("Semestre inválido, se mantiene el anterior.");
            }
        }

        Double ingreso = null;
        Double promedio = null;

        if (tipo.equals("económica")) {
            System.out.print("Nuevo ingreso familiar (" + (b.getIngresoFamiliar() != null ? b.getIngresoFamiliar() : "ninguno") + "): ");
            String ingresoStr = scanner.nextLine().trim();
            if (!ingresoStr.isEmpty()) {
                try {
                    ingreso = Double.parseDouble(ingresoStr);
                } catch (NumberFormatException e) {
                    System.out.println("Ingreso familiar inválido.");
                    return;
                }
            } else {
                ingreso = b.getIngresoFamiliar();
            }
            promedio = null;
        } else if (tipo.equals("académica")) {
            System.out.print("Nuevo promedio académico (" + (b.getPromedioAcademico() != null ? b.getPromedioAcademico() : "ninguno") + "): ");
            String promedioStr = scanner.nextLine().trim();
            if (!promedioStr.isEmpty()) {
                try {
                    promedio = Double.parseDouble(promedioStr);
                } catch (NumberFormatException e) {
                    System.out.println("Promedio académico inválido.");
                    return;
                }
            } else {
                promedio = b.getPromedioAcademico();
            }
            ingreso = null;
        } else {
            System.out.println("Tipo de beca inválido.");
            return;
        }

        boolean exito = controlador.actualizarBeca(cedula, nombres, carrera, tipo, semestre, ingreso, promedio);

        if (exito) {
            System.out.println("Beca actualizada correctamente.");
        } else {
            System.out.println("Error al actualizar la beca.");
        }
    }

    private void eliminarBeca() {
        System.out.print("\nIngrese la cédula para eliminar la beca: ");
        String cedula = scanner.nextLine().trim();
        boolean exito = controlador.eliminarBeca(cedula);
        if (exito) {
            System.out.println("Beca eliminada correctamente.");
        } else {
            System.out.println("Error al eliminar la beca o no existe.");
        }
    }

    private void mostrarBeca(Beca b) {
        System.out.println("------------------------------");
        System.out.println("Cédula: " + b.getCedula());
        System.out.println("Nombres: " + b.getNombres());
        System.out.println("Carrera: " + b.getCarrera());
        System.out.println("Tipo de beca: " + b.getTipoBeca());
        System.out.println("Semestre: " + b.getSemestre());
        if (b.getTipoBeca().equalsIgnoreCase("económica")) {
            System.out.println("Ingreso Familiar: " + (b.getIngresoFamiliar() != null ? b.getIngresoFamiliar() : "No definido"));
        } else if (b.getTipoBeca().equalsIgnoreCase("académica")) {
            System.out.println("Promedio Académico: " + (b.getPromedioAcademico() != null ? b.getPromedioAcademico() : "No definido"));
        }
        System.out.println("------------------------------");
    }

    public static void main(String[] args) {
        VistaConsola vista = new VistaConsola();
        vista.menu();
    }
}
