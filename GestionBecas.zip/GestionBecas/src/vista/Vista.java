/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;
import modelo.Beca;
import modelo.BecaDAO;


import controlador.ControladorBeca;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Vista extends JFrame {

    private ControladorBeca controlador;

    private JTextField cedulaField;
    private JTextField nombresField;
    private JTextField carreraField;
    private JComboBox<String> tipoBecaCombo;
    private JTextField semestreField;
    private JTextField ingresoFamiliarField;
    private JTextField promedioAcademicoField;
    private JButton registrarBtn;
    private JTextArea resultadoArea;

    public Vista() {
        controlador = new ControladorBeca();

        setTitle("Gestión de Becas Universitarias");
        setSize(500, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(10, 2));

        // Campos
        add(new JLabel("Cédula:"));
        cedulaField = new JTextField();
        add(cedulaField);

        add(new JLabel("Nombres:"));
        nombresField = new JTextField();
        add(nombresField);

        add(new JLabel("Carrera:"));
        carreraField = new JTextField();
        add(carreraField);

        add(new JLabel("Tipo de Beca:"));
        tipoBecaCombo = new JComboBox<>(new String[]{"económica", "académica"});
        add(tipoBecaCombo);

        add(new JLabel("Semestre:"));
        semestreField = new JTextField();
        add(semestreField);

        add(new JLabel("Ingreso Familiar (solo económica):"));
        ingresoFamiliarField = new JTextField();
        add(ingresoFamiliarField);

        add(new JLabel("Promedio Académico (solo académica):"));
        promedioAcademicoField = new JTextField();
        add(promedioAcademicoField);

        registrarBtn = new JButton("Registrar Beca");
        add(registrarBtn);

        resultadoArea = new JTextArea();
        resultadoArea.setEditable(false);
        add(new JScrollPane(resultadoArea));

        registrarBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registrarBeca();
            }
        });

        setVisible(true);
    }

    private void registrarBeca() {
        String cedula = cedulaField.getText().trim();
        String nombres = nombresField.getText().trim();
        String carrera = carreraField.getText().trim();
        String tipoBeca = (String) tipoBecaCombo.getSelectedItem();
        String semestreStr = semestreField.getText().trim();
        String ingresoFamiliarStr = ingresoFamiliarField.getText().trim();
        String promedioStr = promedioAcademicoField.getText().trim();

        if (cedula.isEmpty() || nombres.isEmpty() || carrera.isEmpty() || semestreStr.isEmpty()) {
            resultadoArea.setText("Por favor, complete todos los campos obligatorios.");
            return;
        }

        int semestre;
        try {
            semestre = Integer.parseInt(semestreStr);
        } catch (NumberFormatException ex) {
            resultadoArea.setText("El semestre debe ser un número entero.");
            return;
        }

        Double ingresoFamiliar = null;
        Double promedio = null;

        if (tipoBeca.equalsIgnoreCase("económica")) {
            if (ingresoFamiliarStr.isEmpty()) {
                resultadoArea.setText("Debe ingresar el ingreso familiar para beca económica.");
                return;
            }
            try {
                ingresoFamiliar = Double.parseDouble(ingresoFamiliarStr);
            } catch (NumberFormatException ex) {
                resultadoArea.setText("Ingreso familiar inválido.");
                return;
            }
        }

        if (tipoBeca.equalsIgnoreCase("académica")) {
            if (promedioStr.isEmpty()) {
                resultadoArea.setText("Debe ingresar el promedio académico para beca académica.");
                return;
            }
            try {
                promedio = Double.parseDouble(promedioStr);
            } catch (NumberFormatException ex) {
                resultadoArea.setText("Promedio académico inválido.");
                return;
            }
        }

        boolean registrado = controlador.registrarBeca(cedula, nombres, carrera, tipoBeca, semestre, ingresoFamiliar, promedio);
        if (registrado) {
            resultadoArea.setText("Beca registrada exitosamente.");
            limpiarCampos();
        } else {
            resultadoArea.setText("Error al registrar la beca. Verifique los datos.");
        }
    }

    private void limpiarCampos() {
        cedulaField.setText("");
        nombresField.setText("");
        carreraField.setText("");
        semestreField.setText("");
        ingresoFamiliarField.setText("");
        promedioAcademicoField.setText("");
    }

    public static void main(String[] args) {
        new Vista();
    }
}
