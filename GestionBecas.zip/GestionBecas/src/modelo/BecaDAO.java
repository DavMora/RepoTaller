/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import util.ConexionSQLite;
import modelo.Beca;



import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BecaDAO {

    public void crearTabla() {
        String sql = "CREATE TABLE IF NOT EXISTS beca ("
                + "cedula TEXT PRIMARY KEY,"
                + "nombres TEXT NOT NULL,"
                + "carrera TEXT NOT NULL,"
                + "tipo_beca TEXT NOT NULL,"
                + "semestre INTEGER NOT NULL,"
                + "ingreso_familiar REAL,"
                + "promedio_academico REAL,"
                + "montoMensual REAL NOT NULL"
                + ");";
        try (Connection conn = ConexionSQLite.conectar(); Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException ex) {
            System.out.println("Error al crear tabla: " + ex.getMessage());
        }
    }

    public boolean insertar(Beca b) {
        String sql = "INSERT INTO beca (cedula, nombres, carrera, tipoBeca, semestre, ingresoFamiliar, promedioAcademico, montoMensual) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = ConexionSQLite.conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, b.getCedula());
            ps.setString(2, b.getNombres());
            ps.setString(3, b.getCarrera());
            ps.setString(4, b.getTipoBeca());
            ps.setInt(5, b.getSemestre());

            if (b.getIngresoFamiliar() != null) {
                ps.setDouble(6, b.getIngresoFamiliar());
            } else {
                ps.setNull(6, Types.DOUBLE);
            }

            if (b.getPromedioAcademico() != null) {
                ps.setDouble(7, b.getPromedioAcademico());
            } else {
                ps.setNull(7, Types.DOUBLE);
            }

            ps.setDouble(8, b.getMontoMensual());

            ps.executeUpdate();
            return true;
        } catch (SQLException ex) {
            System.out.println("Error al insertar: " + ex.getMessage());
            return false;
        }
    }

    public List<Beca> listar() {
        List<Beca> lista = new ArrayList<>();
        String sql = "SELECT * FROM beca";
        try (Connection conn = ConexionSQLite.conectar();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Beca b = new Beca(
                        rs.getString("cedula"),
                        rs.getString("nombres"),
                        rs.getString("carrera"),
                        rs.getString("tipoBeca"),
                        rs.getInt("semestre"),
                        rs.getObject("ingresoFamiliar") != null ? rs.getDouble("ingresoFamiliar") : null,
                        rs.getObject("promedioAcademico") != null ? rs.getDouble("promedioAcademico") : null
                );
                lista.add(b);
            }

        } catch (SQLException ex) {
            System.out.println("Error al listar: " + ex.getMessage());
        }
        return lista;
    }

    public Beca buscarPorCedula(String cedula) {
        String sql = "SELECT * FROM beca WHERE cedula = ?";
        try (Connection conn = ConexionSQLite.conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, cedula);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new Beca(
                        rs.getString("cedula"),
                        rs.getString("nombres"),
                        rs.getString("carrera"),
                        rs.getString("tipoBeca"),
                        rs.getInt("semestre"),
                        rs.getObject("ingresoFamiliar") != null ? rs.getDouble("ingreso_familiar") : null,
                        rs.getObject("promedioAcademico") != null ? rs.getDouble("promedio_academico") : null
                );
            }

        } catch (SQLException ex) {
            System.out.println("Error al buscar por cédula: " + ex.getMessage());
        }
        return null;
    }

    public boolean actualizar(Beca b) {
        String sql = "UPDATE beca SET nombres = ?, carrera = ?, tipoBeca = ?, semestre = ?, ingresoFamiliar = ?, promedioAcademico = ?, montoMensual = ? WHERE cedula = ?";
        try (Connection conn = ConexionSQLite.conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, b.getNombres());
            ps.setString(2, b.getCarrera());
            ps.setString(3, b.getTipoBeca());
            ps.setInt(4, b.getSemestre());

            if (b.getIngresoFamiliar() != null) {
                ps.setDouble(5, b.getIngresoFamiliar());
            } else {
                ps.setNull(5, Types.DOUBLE);
            }

            if (b.getPromedioAcademico() != null) {
                ps.setDouble(6, b.getPromedioAcademico());
            } else {
                ps.setNull(6, Types.DOUBLE);
            }

            ps.setDouble(7, b.getMontoMensual());
            ps.setString(8, b.getCedula());

            int filas = ps.executeUpdate();
            return filas > 0;
        } catch (SQLException ex) {
            System.out.println("Error al actualizar: " + ex.getMessage());
            return false;
        }
    }

    public boolean eliminar(String cedula) {
        String sql = "DELETE FROM beca WHERE cedula = ?";
        try (Connection conn = ConexionSQLite.conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, cedula);
            int filas = ps.executeUpdate();
            return filas > 0;
        } catch (SQLException ex) {
            System.out.println("Error al eliminar: " + ex.getMessage());
            return false;
        }
    }
}
