/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;


public class Beca {
    private String cedula;
    private String nombres;
    private String carrera;
    private String tipoBeca;
    private int semestre;
    private double montoMensual;
    private Double ingresoFamiliar; 
    private Double promedioAcademico; 

    public Beca(String cedula, String nombres, String carrera, String tipoBeca,
                int semestre, Double ingresoFamiliar, Double promedioAcademico) {
        this.cedula = cedula;
        this.nombres = nombres;
        this.carrera = carrera;
        this.tipoBeca = tipoBeca;
        this.semestre = semestre;
        this.ingresoFamiliar = ingresoFamiliar;
        this.promedioAcademico = promedioAcademico;
        this.montoMensual = calcularMonto();
    }

    private double calcularMonto() {
        if (tipoBeca.equalsIgnoreCase("económica") && ingresoFamiliar != null) {
            if (ingresoFamiliar < 500) return 200;
            else if (ingresoFamiliar <= 1000) return 150;
            else return 100;
        } else if (tipoBeca.equalsIgnoreCase("académica") && promedioAcademico != null) {
            if (promedioAcademico >= 9.5) return 250;
            else if (promedioAcademico >= 8.5) return 200;
            else return 150;
        }
        return 0;
    }

    public String getCedula() { return cedula; }
    public void setCedula(String cedula) { 
        this.cedula = cedula; 
    }

    public String getNombres() { 
        return nombres; 
    }
    public void setNombres(String nombres) { 
        this.nombres = nombres; 
    }

    public String getCarrera() { 
        return carrera; 
    }
    public void setCarrera(String carrera) { 
        this.carrera = carrera; 
    }
    public String getTipoBeca() { 
        return tipoBeca; 
    }
    public void setTipoBeca(String tipoBeca) { 
        this.tipoBeca = tipoBeca; 
    }
    public int getSemestre() { 
        return semestre; 
    }
    public void setSemestre(int semestre) { 
        this.semestre = semestre; 
    }
    public double getMontoMensual() { 
        return montoMensual; }
    public void setMontoMensual(double montoMensual) { 
        this.montoMensual = montoMensual; 
    }
    public Double getIngresoFamiliar() { 
        return ingresoFamiliar; 
    }
    public void setIngresoFamiliar(Double ingresoFamiliar) { 
        this.ingresoFamiliar = ingresoFamiliar; 
    }
    public Double getPromedioAcademico() { 
        return promedioAcademico; 
    }
    public void setPromedioAcademico(Double promedioAcademico) { 
        this.promedioAcademico = promedioAcademico; 
    }
}

