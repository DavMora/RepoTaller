/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.Beca;
import modelo.BecaDAO;
import java.util.ArrayList;

public class ControladorBeca {

    private BecaDAO dao;

    public ControladorBeca() {
        dao = new BecaDAO();
        dao.crearTabla(); // Crear tabla si no existe
    }

    public boolean registrarBeca(String cedula, String nombres, String carrera,
                                 String tipoBeca, int semestre, Double ingresoFamiliar,
                                 Double promedioAcademico) {

        if (tipoBeca == null || (!tipoBeca.equalsIgnoreCase("económica") && !tipoBeca.equalsIgnoreCase("académica"))) {
            System.out.println("Tipo de beca inválido.");
            return false;
        }
        if (tipoBeca.equalsIgnoreCase("económica") && ingresoFamiliar == null) {
            System.out.println("Debe ingresar el ingreso familiar para beca económica.");
            return false;
        }
        if (tipoBeca.equalsIgnoreCase("académica") && promedioAcademico == null) {
            System.out.println("Debe ingresar el promedio académico para beca académica.");
            return false;
        }

        Beca b = new Beca(cedula, nombres, carrera, tipoBeca, semestre, ingresoFamiliar, promedioAcademico);
        return dao.insertar(b);
    }

    public ArrayList<Beca> listarBecas() {
        return (ArrayList<Beca>) dao.listar();
    }

    public Beca buscarBeca(String cedula) {
        return dao.buscarPorCedula(cedula);
    }

    public boolean actualizarBeca(String cedula, String nombres, String carrera,
                                  String tipoBeca, int semestre, Double ingresoFamiliar,
                                  Double promedioAcademico) {

        Beca b = new Beca(cedula, nombres, carrera, tipoBeca, semestre, ingresoFamiliar, promedioAcademico);
        return dao.actualizar(b);
    }

    public boolean eliminarBeca(String cedula) {
        return dao.eliminar(cedula);
    }
}
